using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RecipeSite.Views.Recipes
{
    public class DetailsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
