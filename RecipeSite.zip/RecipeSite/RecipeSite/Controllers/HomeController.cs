using Microsoft.AspNetCore.Mvc;
using RecipeSite.Models;
using RecipeSite.Areas.Identity.Data;
using System.Linq;

namespace RecipeSite.Controllers
{
    public class HomeController : Controller
    {
        private readonly DBRecipeSite _context;

        public HomeController(DBRecipeSite context)
        {
            _context = context;
        }

        public IActionResult Index(string searchString)
        {
            var recipes = from r in _context.Recipes
                          select r;

            if (!string.IsNullOrEmpty(searchString))
            {
                recipes = recipes.Where(s => s.Title.Contains(searchString) || s.Description.Contains(searchString));
            }

            return View(recipes.ToList());
        }
    }
}
